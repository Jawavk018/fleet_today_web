import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ApiService } from 'src/app/providers/api/api.service';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { TokenStorageService } from '../login/token-storage.service';
import { debounceTime, distinctUntilChanged, ReplaySubject, Subject, take, takeUntil } from 'rxjs';
import { FormControl, ReactiveFormsModule } from '@angular/forms';
import { NgxMatSelectSearchModule } from 'ngx-mat-select-search';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';





@Component({
  selector: 'app-driverlist',
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule, NgxMatSelectSearchModule, MatFormFieldModule, MatSelectModule],
  templateUrl: './driverlist.component.html',
  styleUrls: ['./driverlist.component.scss']
})
export class DriverlistComponent implements OnInit {

  selectedDriver: any;
  reason: any;
  user:any;
  search = new Subject<any>();
  searchKey: String = '';
  driverList = [];
  
  public operatorDistrictCtrl: FormControl = new FormControl();
  public operatorDistrictFilterCtrl: FormControl = new FormControl();
  public filteredDistrict: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
  protected _onDestroy = new Subject<void>();
  public districtList: any = [];

  isIndeterminate = false;
  isChecked = false;
  

  constructor(private api: ApiService, private router: Router,private tokenStorage:TokenStorageService) { }

  ngOnInit() {
    
    this.user=this.tokenStorage.getUser();
    this.getDriverDetail();
    this.getCurrentDistrict();
    this.search.pipe(debounceTime(1000), distinctUntilChanged())
    .subscribe((value: any) => {
      this.driverList = [];
      this.getDriverDetail();
    });

    this.operatorDistrictFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {
        this.filterDistrict();
      });

  }

  
  getCurrentDistrict() {
    this.districtList = [];
    let params: any = {};
    this.api.get("8053/api/get_current_district", params).subscribe(result => {
      console.log(result)
      if (result.data != null && result.data.length > 0) {
        this.districtList = result.data;
        this.filteredDistrict.next(this.districtList.slice());
        console.log(this.districtList);
      } else {
      }
    });
  }

  toggleDistrictSelectAll(selectAllValue: boolean) {
    this.filteredDistrict
      .pipe(take(1), takeUntil(this._onDestroy))
      .subscribe((val) => {
        if (selectAllValue) {
          let districtList = [];
          for (let obj of val) {
            districtList.push(obj);
          }
          this.operatorDistrictCtrl.patchValue(districtList);
        } else {
          this.operatorDistrictCtrl.patchValue([]);
        }
      });
  }

  protected filterDistrict() {
    if (!this.districtList) {
      return;
    }
    let search = this.operatorDistrictFilterCtrl.value;
    if (!search) {
      this.filteredDistrict.next(this.districtList.slice());
      return;
    } else {
      search = search?.toLowerCase();
    }
    this.filteredDistrict.next(
      this.districtList.filter((obj) => obj?.toLowerCase().indexOf(search) > -1)
    );
  }

  getDriverDetail() {
    let params: any = { activeFlag: true, searchKey: this.searchKey };
    if (this.operatorDistrictCtrl.value?.length) {
      let type: String = typeof this.operatorDistrictCtrl.value;
      console.log(type === 'Object');
      if (type === 'Object') {
        params.district = this.operatorDistrictCtrl.value;
      } else {
        params.district = [];
        for (let i in this.operatorDistrictCtrl.value) {
          console.log(this.operatorDistrictCtrl.value[i])
          params.district.push(this.operatorDistrictCtrl.value[i]);
        }
      }
      params.district = JSON.stringify(params.district);
    }
    console.log(params);
    this.api.get('8055/api/get_driver_dtl', params).subscribe(result => {
      if (result != null && result.data) {
        this.driverList = result.data;
        console.log(this.driverList)
      } else {

      }
    })

  }

  openModal(index: any) {
    this.selectedDriver = this.driverList[index];
    console.log(JSON.stringify(this.selectedDriver))
  }

  changeStatus(type: any) {
    let body: any = { driverSno: this.selectedDriver.driverSno, kycStatus: type == 'Approve' ? 19 : 58, type: type };
    body.createdOn=this.api.networkData.timezone;
    if (type == 'Reject') {
      body.rejectReason = this.reason
    }
    console.log('BODY',body)
    this.api.post('8053/api/accept_reject_driver_kyc', body).subscribe(result => {
      if (result != null) {
        this.getDriverDetail();
        this.reason = null;
      }

    })
  }

  gotoViewDriver(i?: any, isCopy?: string) {
    let navigationExtras: any = {
      state: {
        driver: this.driverList[i],
        isCopy: isCopy == 'copy' ? true : false
      }
    };
    this.router.navigate(['/view-driver'], navigationExtras);
  }

  updateFilter(){

  }

  
}
